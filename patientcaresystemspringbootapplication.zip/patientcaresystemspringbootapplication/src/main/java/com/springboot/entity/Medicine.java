package com.springboot.entity;

import com.fasterxml.jackson.annotation.JsonBackReference;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Entity
@Table(name = "medicines")
public class Medicine {
	
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int medicineId;
	
	
	@Column(length = 25, nullable = false)
	@NotBlank(message = "Medicine name can not be Blank")
	private String medicineName;
	
	
	@Column(length = 100, nullable = false)
	@NotBlank(message = "Medicine name can not be Blank")
	private String medicineDescription;
	
	
	@Column(length = 25, nullable = false)
	@NotBlank(message = "Medicine price can not be Blank")
	private int medicinePrice;
	
	
	
	
	
	
	
	
	
	
	
//	@ManyToOne(fetch =FetchType.EAGER, cascade = CascadeType.ALL)
//	@JoinColumn(name="preId", referencedColumnName = "prescriptionId")
//	@JsonBackReference
//	private Prescription prescription;
	
	

}
