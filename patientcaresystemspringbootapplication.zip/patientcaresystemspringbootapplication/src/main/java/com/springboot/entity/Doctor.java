package com.springboot.entity;

import java.util.List;
import java.util.Set;

import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@NoArgsConstructor		//default constructor
@AllArgsConstructor		//parameterized constructor
@ToString				//to string method
@Entity
@Table(name = "doctors")
public class Doctor {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int doctorId;
	
	
	@Column(length = 25, nullable = false, unique = true)
	@NotBlank(message = "Doctor Registration Id can not be blank..")
	private String doctorRegistrationId;
	
	
	@Column(length=25, nullable = false)						//nullable - do not null field
	@NotBlank(message="Doctor name can not be blank..") 		// validation
	private String doctorName;
	
	
	@Column(length = 25, nullable = false)
	@NotBlank(message = "Doctor experience can not be blank..")
	private String doctorExperience;
	
	
	@Column(length = 25, nullable = false)
	@NotBlank(message = "Doctor gender can not be blank..")
	private String doctorGender;
	
	
	@Column(length = 100, nullable = false)
	@NotBlank(message = "Doctor address can not be blank..")
	private String doctorAddress;
	
	
	@Column(length = 10, nullable = false, unique = true)
	@NotBlank(message = "Doctor phone number can not be blank..")
	@Size(min=10,max=10)
	@Pattern(regexp="(^$|[0-9]{10})")
	private String doctorPhoneNo;
	
	
	@Column(length = 10, nullable = false)
	@NotBlank(message = "Doctor specialization can not be blank..")
	private String doctorSpecialization;
	
	
	
	
	
	
	
	
	
	
	
	
	
	
//	@Column(length = 10, nullable = false)
//	@NotBlank(message = "Doctor Email Id can not be blank..")
//	private String doctorEmailId;
//	
//	
//	@Column(length = 10, nullable = false)
//	@NotBlank(message = "Doctor Password can not be blank..")
//	private String doctorPassword;
	
	
	
	
//	@OneToMany(mappedBy = "doctor",  
//			fetch = FetchType.EAGER, cascade = CascadeType.ALL)		//CascadeType = changing the value
//			@JsonManagedReference
//			private List<Appointment> appointmentList;
	
	
	
	
	
//	@OneToMany(mappedBy = "doctor",  
//			fetch = FetchType.EAGER, cascade = CascadeType.ALL)		//CascadeType = changing the value
//			@JsonManagedReference
//			private List<Prescription> prescriptionList;
	
	
	
	
//	@ManyToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
//	@JoinTable(
//		name = "doctorSchedule",
//		joinColumns = @JoinColumn(name = "doctorId"),
//		inverseJoinColumns = @JoinColumn(name = "doctorScheduleId")
//	)
//	@JsonManagedReference
//	private Set<DoctorSchedule> schedules;
	
	
	
	
	
	
	
	
//	@ManyToOne(fetch =FetchType.EAGER, cascade = CascadeType.ALL)
//	@JoinColumn(name="pId", referencedColumnName = "patient_id")
//	@JsonBackReference
//	private Patient patient;
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
//	@OneToMany(mappedBy = "doctor")
//    @JsonManagedReference("doctor-appointment")
//    private List<Appointment> appointmentList;

	
//	@OneToOne(mappedBy = "doctor", cascade = CascadeType.ALL)
//    private Appointment appointment;
	
}
