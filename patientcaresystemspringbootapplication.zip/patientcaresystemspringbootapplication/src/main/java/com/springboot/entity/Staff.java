package com.springboot.entity;


import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@NoArgsConstructor		//default constructor
@AllArgsConstructor		//parameterized constructor
@ToString				//to string method
@Entity
@Table(name = "staffs")
public class Staff {
	
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int staffId;
	
	
	@Column(length=25, nullable = false)						//nullable - do not null field
	@NotBlank(message="Staff name can not be blank..") 		// validation
	private String staffName;
	
	
	@Column(length = 25, nullable = false)
	@NotBlank(message = "Staff gender can not be blank..")
	private String staffGender;
	
	
	@Column(length = 100, nullable = false)
	@NotBlank(message = "Staff address can not be blank..")
	private String staffAddress;
	
	
	@Column(length = 11, nullable = false, unique = true)
	@NotBlank(message = "Staff phone number can not be blank..")
	@Size(min=10,max=10)
	@Pattern(regexp="(^$|[0-9]{10})")
	private String staffPhoneNo;
	
	

}
