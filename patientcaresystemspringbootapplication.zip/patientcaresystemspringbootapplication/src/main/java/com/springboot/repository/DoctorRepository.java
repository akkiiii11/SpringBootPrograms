package com.springboot.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.springboot.entity.Doctor;

public interface DoctorRepository extends JpaRepository<Doctor, Integer> {
	
//	@Query("SELECT d FROM Doctor d WHERE d.name = :name")
//	List<Doctor> findDoctorByName(@Param("name") String name);

}
