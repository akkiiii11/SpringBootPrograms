package com.springboot.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springboot.entity.DoctorSchedule;
import com.springboot.exception.DoctorScheduleIdNotFoundException;
import com.springboot.repository.DoctorScheduleRepository;
import com.springboot.service.DoctorScheduleService;


@Service
public class DoctorScheduleServiceImpl implements DoctorScheduleService{

	@Autowired
	DoctorScheduleRepository doctorScheduleRepository;
	
	@Override
	public DoctorSchedule addDoctorSchedule(DoctorSchedule doctorSchedule) {
		
		return doctorScheduleRepository.save(doctorSchedule);
	}

	
	@Override
	public List<DoctorSchedule> getAllDoctorSchedules() {
		
		return doctorScheduleRepository.findAll();
	}

	
	
	@Override
	public DoctorSchedule getDoctorScheduleById(int doctorScheduleId) {
		
		return doctorScheduleRepository.findById(doctorScheduleId).
				orElseThrow(()-> new DoctorScheduleIdNotFoundException("Doctor Schedule id is not corrected"));
	}

	
	@Override
	public DoctorSchedule updateDoctorSchedule(DoctorSchedule doctorSchedule, int doctorScheduleId) {
		
		DoctorSchedule updateDoctorSchedule = doctorScheduleRepository.findById(doctorScheduleId).
				orElseThrow(()-> new DoctorScheduleIdNotFoundException("Doctor Schedule id is not corrected"));
		
				// set new value
		updateDoctorSchedule.setDoctorScheduleDay(doctorSchedule.getDoctorScheduleDay());
		updateDoctorSchedule.setDoctorScheduleTimeFrom(doctorSchedule.getDoctorScheduleTimeFrom());
		updateDoctorSchedule.setDoctorScheduleTimeTo(doctorSchedule.getDoctorScheduleTimeTo());
				
			
				doctorScheduleRepository.save(updateDoctorSchedule);
				return updateDoctorSchedule;
	}

	
	@Override
	public void deleteDoctorSchedule(int doctorScheduleId) {
		
		DoctorSchedule deleteDoctorSchedule = doctorScheduleRepository.findById(doctorScheduleId).
				orElseThrow(()-> new DoctorScheduleIdNotFoundException("Doctor Schedule id is not corrected"));
				doctorScheduleRepository.delete(deleteDoctorSchedule);	
		
	}

}
