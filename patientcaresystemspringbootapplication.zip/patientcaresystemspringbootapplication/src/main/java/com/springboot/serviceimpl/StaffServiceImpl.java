package com.springboot.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springboot.entity.Staff;
import com.springboot.exception.StaffIdNotFoundException;
import com.springboot.repository.StaffRepository;
import com.springboot.service.StaffService;


@Service
public class StaffServiceImpl implements StaffService{
	
	@Autowired
	StaffRepository staffRepository;
	
	@Override
	public Staff addStaff(Staff staff) {
		
		return staffRepository.save(staff);
	}
	
	
	
	@Override
	public List<Staff> getAllStaffs() {
		
		return staffRepository.findAll();
	}

	
	

	@Override
	public Staff getStaffById(int staffId) {
		
		return staffRepository.findById(staffId).
				orElseThrow(()-> new StaffIdNotFoundException("Staff id is not corrected.."));
	}

	
	
	
	@Override
	public Staff updateStaff(Staff staff, int staffId) {
		
		Staff updateStaff =  staffRepository.findById(staffId).
				orElseThrow(()-> new StaffIdNotFoundException("Staff id is not corrected"));
		
				// set new value
		updateStaff.setStaffName(staff.getStaffName());
		updateStaff.setStaffGender(staff.getStaffGender());
		updateStaff.setStaffAddress(staff.getStaffAddress());
		updateStaff.setStaffPhoneNo(staff.getStaffPhoneNo());
			
				staffRepository.save(updateStaff);
				return updateStaff;
	}
	
	
	

	@Override
	public void deleteStaff(int staffId) {
		
		Staff deleteStaff = staffRepository.findById(staffId).
				orElseThrow(()-> new StaffIdNotFoundException("Staff id is not corrected"));
				staffRepository.delete(deleteStaff);
		
	}

}
