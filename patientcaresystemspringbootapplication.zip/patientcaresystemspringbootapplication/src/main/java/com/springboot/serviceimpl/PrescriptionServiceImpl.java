package com.springboot.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springboot.entity.Prescription;
import com.springboot.exception.PrescriptionIdNotFoundException;
import com.springboot.repository.PrescriptionRepository;
import com.springboot.service.PrescriptionService;

@Service
public class PrescriptionServiceImpl implements PrescriptionService{

	@Autowired
	PrescriptionRepository prescriptionRepository;
	
	@Override
	public Prescription addPrescription(Prescription prescription) {
		
		return prescriptionRepository.save(prescription);
	}
	
	
	
	@Override
	public List<Prescription> getAllPrescriptions() {
		
		return prescriptionRepository.findAll();
	}

	
	

	@Override
	public Prescription getPrescriptionById(int prescriptionId) {
		
		return prescriptionRepository.findById(prescriptionId).
				orElseThrow(()-> new PrescriptionIdNotFoundException("Prescription id is not corrected.."));
	}

	
	
	
	@Override
	public Prescription updatePrescription(Prescription prescription, int prescriptionId) {
		
		Prescription UpdatePrescription =  prescriptionRepository.findById(prescriptionId).
				orElseThrow(()-> new PrescriptionIdNotFoundException("Prescription id is not corrected"));
		
				// set new value
				UpdatePrescription.setDose(prescription.getDose());
				UpdatePrescription.setDuration(prescription.getDuration());
			
				prescriptionRepository.save(UpdatePrescription);
				return UpdatePrescription;
	}
	
	
	

	@Override
	public void deletePrescription(int prescriptionId) {
		
		Prescription deletePrescription = prescriptionRepository.findById(prescriptionId).
				orElseThrow(()-> new PrescriptionIdNotFoundException("Prescription id is not corrected"));
				prescriptionRepository.delete(deletePrescription);
		
	}

}
