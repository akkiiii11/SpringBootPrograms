package com.springboot.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springboot.entity.Patient;
import com.springboot.exception.PatientIdNotFoundException;
import com.springboot.repository.PatientRepository;
import com.springboot.service.PatientService;

@Service			//it is layer
public class PatientServiceImpl implements PatientService {

	@Autowired
	PatientRepository patientRepository;
	
	@Override
	public Patient addPatient(Patient patient) {

		return patientRepository.save(patient);
	}
	
	
	
	@Override
	public List<Patient> getAllPatients() {
		
		return patientRepository.findAll();
	}
	
	
	

	@Override
	public Patient getPatientById(int patientId) {
		
		return patientRepository.findById(patientId).
				orElseThrow(()-> new PatientIdNotFoundException("Patient id is not corrected"));
	}

	
	
//	@Override
//	public List<Patient> getPatientByName(String patientName) {
//		
//		return patientRepository.findPatientByName(patientName);
//	}
//
//	
//
//	@Override
//	public Patient getPatientByEmailId(String patientEmailId) {
//		
//		return patientRepository.findPatientByEmailId(patientEmailId);
//	}
//
//
//	
//	@Override
//	public Patient getPatientByPhoneNumber(int patientPhoneNo) {
//		
//		return patientRepository.findPatientByPhoneNo(patientPhoneNo);
//	}
//	
//	
//	
//	@Override
//	public List<Patient> getPatientByBloodGroup(String patientBloodGroup) {
//		
//		return patientRepository.findPatientByBloodGroup(patientBloodGroup);
//	}
	
	
	
	
	@Override
	public Patient updatePatient(Patient patient, int patientId) {
		
		Patient updatePatient = patientRepository.findById(patientId).
				orElseThrow(()-> new PatientIdNotFoundException("Patient id is not corrected"));
		
				// set new value
			updatePatient.setPatientName(patient.getPatientName());
			updatePatient.setPatientDateOfBirth(patient.getPatientDateOfBirth());
			updatePatient.setPatientGender(patient.getPatientGender());
			updatePatient.setPatientBloodGroup(patient.getPatientBloodGroup());
			updatePatient.setPatientAddress(patient.getPatientAddress());
			updatePatient.setPatientPhoneNo(patient.getPatientPhoneNo());
			
			patientRepository.save(updatePatient);
			return updatePatient;

	}
	
	
	

	@Override
	public void deletePatient(int patientId) {

		Patient deletePatient = patientRepository.findById(patientId).
				orElseThrow(()-> new PatientIdNotFoundException("Patient id is not corrected"));
				patientRepository.delete(deletePatient);
		
	}



	


}
