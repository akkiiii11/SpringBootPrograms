package com.springboot.serviceimpl;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springboot.entity.Appointment;
import com.springboot.exception.AppointmentIdNotFoundException;
import com.springboot.repository.AppointmentRepository;
import com.springboot.service.AppointmentService;

@Service
public class AppointmentServiceImpl implements AppointmentService{

	@Autowired
	AppointmentRepository appointmentRepository;
	
	@Override
	public Appointment addAppointment(Appointment appointment) {
		
		return appointmentRepository.save(appointment);
	}

	
	
	@Override
	public List<Appointment> getAllAppointments() {
		
		return appointmentRepository.findAll();
	}
	
	
	
	
	@Override
	public Appointment getAppointmentById(int appointmentId) {
		
		return appointmentRepository.findById(appointmentId).
				orElseThrow(()-> new AppointmentIdNotFoundException("Appointment id is not corrected"));
	}
	
	
	
	@Override
	public Appointment updateAppointment(Appointment appointment, int appointmentId) {
		
		Appointment updateAppointment = appointmentRepository.findById(appointmentId).
				orElseThrow(()-> new AppointmentIdNotFoundException("Appointment id is not corrected"));
		
				// set new value
		updateAppointment.setAppointmentDate(appointment.getAppointmentDate());
		updateAppointment.setPatientName(appointment.getPatientName());
				
			
				appointmentRepository.save(updateAppointment);
				return updateAppointment;
	}
	
	
	
	
	
	
//	@Override
//	public List<Appointment> getAppointmentByDate(LocalDate appointmentDate) {
//		
//		
//		return appointmentRepository.findAppointmentByDate(appointmentDate);
//		
//		
//	}

	
	
	@Override
	public void deleteAppointment(int appointmentId) {
		
		Appointment deleteAppointment = appointmentRepository.findById(appointmentId).
				orElseThrow(()-> new AppointmentIdNotFoundException("Appointment id is not corrected"));
				appointmentRepository.delete(deleteAppointment);
		
	}	

}
