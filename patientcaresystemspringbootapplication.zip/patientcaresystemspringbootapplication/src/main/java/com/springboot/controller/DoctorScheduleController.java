package com.springboot.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.springboot.entity.DoctorSchedule;
import com.springboot.service.DoctorScheduleService;

import jakarta.validation.Valid;


@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api/v3/")
public class DoctorScheduleController {
	
	@Autowired
	DoctorScheduleService doctorScheduleService;
	
	
	
	@PostMapping("/DoctorSchedule")
	public ResponseEntity<DoctorSchedule> saveDoctorSchedule(@Valid @RequestBody DoctorSchedule doctorSchedule) 
	{
		
		return new ResponseEntity<DoctorSchedule>(doctorScheduleService.addDoctorSchedule(doctorSchedule), HttpStatus.CREATED);
		
	}
	
	
	
	@GetMapping("/DoctorSchedule")
	public List<DoctorSchedule> getAllDoctorSchedules(){
		
		return doctorScheduleService.getAllDoctorSchedules();
	}	
	
	
	
	@GetMapping("/DoctorSchedule/{doctorScheduleId}")
	public ResponseEntity<DoctorSchedule> getDoctorScheduleById(@PathVariable ("doctorScheduleId") int doctorScheduleId)
	{
		return new ResponseEntity<DoctorSchedule>(doctorScheduleService.getDoctorScheduleById(doctorScheduleId),HttpStatus.OK);
	}
	
		
	
	
	
	@DeleteMapping("/DoctorSchedule/{doctorScheduleId}")
	public ResponseEntity<String> deleteDoctorSchedule(@PathVariable ("doctorScheduleId") int doctorScheduleId)
	{
		doctorScheduleService.deleteDoctorSchedule(doctorScheduleId);
		return new ResponseEntity<String>("Deleted Sucessfully", HttpStatus.OK);
	}
	
	
	
	
	
	@PutMapping("/DoctorSchedule/{doctorScheduleId}")
    public ResponseEntity<String> updateDoctorSchedule(@RequestBody DoctorSchedule doctorSchedule, @PathVariable("doctorScheduleId") int doctorScheduleId) {
		doctorScheduleService.updateDoctorSchedule(doctorSchedule, doctorScheduleId); 										// Delegate to service layer
        return new ResponseEntity<String>("Updated Successfully", HttpStatus.OK);
    }

}
