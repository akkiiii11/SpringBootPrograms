package com.springboot.controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.springboot.entity.Appointment;
import com.springboot.service.AppointmentService;

import jakarta.validation.Valid;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api/v1/")
public class AppointmentController {
	
	@Autowired
	AppointmentService appointmentService;
	
	
	
	@PostMapping("/Appointment")
	public ResponseEntity<Appointment> saveAppointment(@Valid @RequestBody Appointment appointment) 
	{
		
		return new ResponseEntity<Appointment>(appointmentService.addAppointment(appointment), HttpStatus.CREATED);
		
	}
	
	
	@GetMapping("/Appointment")
	public List<Appointment> getAllAppointments(){
		
		return appointmentService.getAllAppointments();
	}
	
	
	
	
	@GetMapping("/Appointment/{appointmentId}")
	public ResponseEntity<Appointment> getAppointmentById(@PathVariable ("appointmentId") int appointmentId)
	{
		return new ResponseEntity<Appointment>(appointmentService.getAppointmentById(appointmentId),HttpStatus.OK);
	}
	
	
	
	
//	@GetMapping("/Appointment")
//	public List<Appointment> getAppointmentsByDate(LocalDate appointmentDate){
//		
//		return appointmentService.getAppointmentByDate(appointmentDate);
//	}
	
	
	
	
	@DeleteMapping("/Appointment/{appointmentId}")
	public ResponseEntity<String> deleteAppointment(@PathVariable ("appointmentId") int appointmentId)
	{
		appointmentService.deleteAppointment(appointmentId);
		return new ResponseEntity<String>("Deleted Sucessfully", HttpStatus.OK);
	}
	
	
	@PutMapping("/Appointment/{appointmentId}")
    public ResponseEntity<String> updateAppointment(@RequestBody Appointment appointment, @PathVariable("appointmentId") int appointmentId) {
		appointmentService.updateAppointment(appointment, appointmentId); 										// Delegate to service layer
        return new ResponseEntity<String>("Updated Successfully", HttpStatus.OK);
    }


}
