package com.springboot.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.springboot.entity.Patient;
import com.springboot.service.PatientService;

import jakarta.validation.Valid;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api/v5/")
public class PatientController {
	
	
	@Autowired
	PatientService patientService;
	
	
	
	@PostMapping("/Patient")
	public ResponseEntity<Patient> savePatient(@Valid @RequestBody Patient patient) 
	{
		
		return new ResponseEntity<Patient>(patientService.addPatient(patient), HttpStatus.CREATED);
	}
	
	
	@GetMapping("/Patient")
	public List<Patient> getAllPatients(){
		
		return patientService.getAllPatients();
	}
	
	
	
	@GetMapping("/Patient/{patientId}")
	public ResponseEntity<Patient> getPatientById(@PathVariable ("patientId") int patientId)
	{
		return new ResponseEntity<Patient>(patientService.getPatientById(patientId),HttpStatus.OK);
	}
	
	
	
//	@GetMapping("/Patient")
//	public List<Patient> getPatientByName(String patientName){
//		
//		return patientService.getPatientByName(patientName);
//	}
//	
//	
//	
//	@GetMapping("/Patient")
//	public Patient getPatientByEmailId(String patientEmailId){
//		
//		return patientService.getPatientByEmailId(patientEmailId);		
//	}
//	
//	
//	
//	@GetMapping("/Patient")
//	public Patient getPatientByPhoneNo(int patientPhoneNo){
//		
//		return patientService.getPatientByPhoneNumber(patientPhoneNo);
//	}
//	
//	
//	
//	@GetMapping("/Patient")
//	public List<Patient> getPatientByBloodGroup(String patientBloodGroup){
//		
//		return patientService.getPatientByBloodGroup(patientBloodGroup);
//	}
	
	
	
	
	@DeleteMapping("/Patient/{patientId}")
	public ResponseEntity<String> deletePatient(@PathVariable ("patientId") int patientId)
	{
		patientService.deletePatient(patientId);
		return new ResponseEntity<String>("Deleted Sucessfully", HttpStatus.OK);
	}
	
	
	
	
	@PutMapping("/Patient/{patientId}")
    public ResponseEntity<String> updatePatient(@RequestBody Patient patient, @PathVariable("patientId") int patientId) {
		patientService.updatePatient(patient, patientId); 										// Delegate to service layer
        return new ResponseEntity<String>("Updated Successfully", HttpStatus.OK);
    }
	

}
