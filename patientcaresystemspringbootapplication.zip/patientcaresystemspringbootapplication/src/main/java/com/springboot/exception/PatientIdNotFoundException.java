package com.springboot.exception;

public class PatientIdNotFoundException extends RuntimeException {
	
	public PatientIdNotFoundException(String message)
	{
		
		super(message);
		
	}

}
