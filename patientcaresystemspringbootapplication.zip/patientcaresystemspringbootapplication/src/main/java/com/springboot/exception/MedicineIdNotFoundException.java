package com.springboot.exception;

public class MedicineIdNotFoundException extends RuntimeException {
	
	public MedicineIdNotFoundException(String message)
	{
		
		super(message);
		
	}

}