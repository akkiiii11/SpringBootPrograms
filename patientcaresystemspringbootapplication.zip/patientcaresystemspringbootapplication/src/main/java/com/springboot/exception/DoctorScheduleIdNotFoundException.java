package com.springboot.exception;

public class DoctorScheduleIdNotFoundException extends RuntimeException {
	
	public DoctorScheduleIdNotFoundException(String message)
	{
		
		super(message);
		
	}

}
