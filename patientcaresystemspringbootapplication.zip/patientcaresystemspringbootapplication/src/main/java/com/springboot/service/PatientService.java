package com.springboot.service;

import java.util.List;

import com.springboot.entity.Patient;

public interface PatientService {
	

		Patient addPatient(Patient patient);
		
		
		List<Patient> getAllPatients();
		
		
		Patient getPatientById(int patientId);
		
		
//		List<Patient> getPatientByName(String patientName);
		
		
//		Patient getPatientByEmailId(String patientEmailId);
		
		
//		Patient getPatientByPhoneNumber(int patientPhoneNo);
		
		
//		List<Patient> getPatientByBloodGroup(String patientBloodGroup);
		
		
		Patient updatePatient(Patient patient, int patientId);
		
		
		void deletePatient(int patientId);

}
