package com.springboot.service;

import java.util.List;

import com.springboot.entity.Staff;


public interface StaffService {
	
	Staff addStaff(Staff staff);
	
	List<Staff> getAllStaffs();
	
	Staff getStaffById(int StaffId);
	
	Staff updateStaff(Staff staff, int staffId);
	
	void deleteStaff(int staffId);

}
