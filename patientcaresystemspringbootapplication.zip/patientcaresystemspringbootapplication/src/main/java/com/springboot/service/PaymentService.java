package com.springboot.service;

import java.time.LocalDateTime;
import java.util.List;

import com.springboot.entity.Payment;

public interface PaymentService {
	
		
		Payment addPayment(Payment payment);
		
		
		List<Payment> getAllPayments();
		
	
		Payment getPaymentById(int paymentId);
		
		
		Payment updatePayment(Payment payment, int paymentId);
		
		
		void deletePayment(int paymentId);
		
		
//		List<Payment> getPaymentByDate(LocalDateTime PaymentDate);

}
