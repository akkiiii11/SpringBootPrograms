package com.springboot.service;

import java.time.LocalDate;
import java.util.List;

import com.springboot.entity.Appointment;



public interface AppointmentService {
	
				
				Appointment addAppointment(Appointment appointment);
				
				
				List<Appointment> getAllAppointments();
				
				
				Appointment getAppointmentById(int appointmentId);
				
				
//				List<Appointment> getAppointmentByDate(LocalDate appointmentDate);
				
				Appointment updateAppointment(Appointment appointment, int appointmentId);
				
				
				void deleteAppointment(int appointmentId);

}
