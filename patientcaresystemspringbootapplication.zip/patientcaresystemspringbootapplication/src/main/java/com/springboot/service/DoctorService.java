package com.springboot.service;

import java.util.List;

import com.springboot.entity.Doctor;

public interface DoctorService {
	
			
			Doctor addDoctor(Doctor doctor);
			
			
			List<Doctor> getAllDoctors();
			
			
			Doctor getDoctorById(int doctorId);
			
			
//			List<Doctor> getDoctorByName(String doctorName);
			
			
			Doctor updateDoctor(Doctor doctor, int doctorId);
			
			
			void deleteDoctor(int doctorId);

}
