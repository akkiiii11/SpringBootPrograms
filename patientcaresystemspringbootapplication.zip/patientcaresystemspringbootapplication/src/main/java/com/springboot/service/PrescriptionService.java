package com.springboot.service;

import java.util.List;

import com.springboot.entity.Prescription;

public interface PrescriptionService {
	
	
	Prescription addPrescription(Prescription prescription);
	
	
	List<Prescription> getAllPrescriptions();
	
	
	Prescription getPrescriptionById(int prescriptionId);
	
	
	Prescription updatePrescription(Prescription prescription, int prescriptionId);
	
	
	void deletePrescription(int prescriptionId);

}
